<?php include '../pages/includes/header.php'?>

<section class="py-5">
    <div class="container">
        <div class="row">
            <div class="col-md-8 mx-auto">
                <div class="card">
                    <div class="card-header">
                        <h4>Please Fill The From Carefully</h4>
                    </div>

                  <div class="card-body">
                    <?php if(isset($message)) { ?>
                        <h4 class="text-center text-success"><?php echo $message;?></h4>

                        <?php } ?>
                    <h4 class="text-center text-success"><?php $message; ?></h4>
                        <form action="action.php" method="POST" enctype="multipart/form-data">
                        <div class="form-group row mt-3">
                            <label for="" class="col-form-label col-md-3">Name</label>                
                            <div class="col-md-9">
                                <input type="text" name="name" class="form-control">
                            </div>

                        </div>
                        <div class="form-group row mt-3">
                            <label for="" class="col-form-label col-md-3">Email</label>                
                            <div class="col-md-9">
                                <input type="email" name="email" class="form-control">
                            </div>

                        </div>

                        <div class="form-group row mt-3">
                            <label for="" class="col-form-label col-md-3">Mobile</label>                
                            <div class="col-md-9">
                                <input type="mobile" name="mobile" class="form-control">
                            </div>

                        </div>

                        <div class="form-group row mt-3">
                            <label for="" class="col-form-label col-md-3">Image</label>                
                            <div class="col-md-9">
                                <input type="file" name="image" class="form-control-file">
                            </div>

                        </div>

                        <div class="form-group row mt-5">
                            <label for="" class="col-form-label col-md-3"></label>                
                            <div class="col-md-9">
                            <input type="submit" name="btn" class="btn btn-outline-success btn-block">
                        </div>

                        </div>

                    <div class="form">

                    

                    </div>
                    </form>

                    </div>

                </div>

            </div>

        </div>

    </div>

</section>


<?php include '../pages/includes/footer.php'?>


