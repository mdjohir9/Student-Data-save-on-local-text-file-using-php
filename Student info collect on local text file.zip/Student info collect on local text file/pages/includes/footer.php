<script src="../assets/js/bootstrap.js"></script>    
<script src="../assets/js/bootstrap.min.js"></script>    
</body>
</html>