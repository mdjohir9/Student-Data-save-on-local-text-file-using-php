<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>File Uploade Project</title>
    <link rel="stylesheet" href="../assets/css/bootstrap.css">
</head>
<body>

<nav class="navbar navbar-expand-md navbar-dark bg-dark ">

<div class="container">
    <a href="" class="navbar-brand">LOGO</a>
    <ul class="navbar-nav">
        <li><a href="home.php" class="nav-link">Add Student</a></li> 
        <li><a href="action.php?status=manage" class="nav-link">Manage Student</a></li> 
        <li><a href="" class="nav-link">Login</a></li> 

    </ul>

</div>
</nav>

