<?php

use App\classes\Student;

 include '../pages/includes/header.php'?>

<section class="py-5">
    <div class="container">
        <div class="row">
            <div class="col-md-8 mx-auto">
                <div class="card">
                    <div class="card-header text-center">
                        <h4 >Please Fill The From Carefully</h4>
                    </div>

                  <div class="card-body">

                    <table class="table table-border">
                        <thead>
                            <tr class="">
                                
                                <th>Student Name</th>                              
                                <th>Email</th>
                                <th>Mobile</th>
                                <th>Image</th>
                            </tr>

                        </thead>

                        <tbody>
                        <?php foreach($students as $student) { ?>

                            <tr>
                                <td><?php echo $student['name']; ?></td>
                                <td><?php echo $student['email']; ?></td>
                                <td><?php echo $student['mobile']; ?></td>
                                <td>
                                    
                                <img src="<?php echo $student['image']; ?>"  height="100" width="150">
                            
                                </td>
                                
                                
                            </tr>
                        <?php } ?>

                           
                        </tbody>
                    </table>
                    

                  </div>

                </div>

            </div>

        </div>

    </div>

</section>


<?php include '../pages/includes/footer.php'?>


